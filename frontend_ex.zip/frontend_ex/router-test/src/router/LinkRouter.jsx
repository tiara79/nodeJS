import { createBrowserRouter } from "react-router-dom";
import RootPage from "../pages/RootPage";
import MainPage from "../pages/MainPage";
import AboutPage from "../pages/AboutPage";
import ArticlePage from "../pages/ArticlePage";

const linkRouter = createBrowserRouter( 
  [
     { path:'/' 
      , element: <RootPage />
      , errorElement : <h1>404 요청이 잘못 되었습니다.</h1>
      ,children : [ 
          { index: true, 
            element : <MainPage />
          },
          { path: '/about', 
            element : <AboutPage />
          },
          { path: '/article', 
            element : <ArticlePage />
          },
      ]
     }
  ]
);

export default linkRouter;