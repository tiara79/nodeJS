import React from "react"

export default function ArticlePage(){
  return(
    <h1> ArticlePage </h1>
  );
}
