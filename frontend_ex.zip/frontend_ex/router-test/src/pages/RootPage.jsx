
import { Outlet, NavLink } from "react-router-dom";

export default function RootPage(){
   
  return(
    <>
      <h1>Root Page</h1>
      <nav>
        <ul>
          <li><NavLink to='/' >홈</NavLink></li>
          <li><NavLink to='/about'>기사</NavLink></li>
          <li><NavLink to='/article'>회사소개</NavLink></li>
        </ul>
      </nav>
      <Outlet></Outlet>
    </>
  );
}