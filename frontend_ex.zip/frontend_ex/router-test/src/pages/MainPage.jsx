import React from "react"


export default function MainPage(){

  return(
    <h1> Main Page </h1>
  );
}
