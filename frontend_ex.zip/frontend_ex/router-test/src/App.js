import './App.css';
import { RouterProvider } from 'react-router-dom';
// import router from './router/basicRouter';
import linkRouter from './router/LinkRouter'

function App() {
  return (
   <RouterProvider router={ linkRouter } />
  );
}

export default App;
