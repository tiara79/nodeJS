
import './App.css';
// import CustomOverayTest from './components/CustomOverayTest';
// import MapMarkerTest from './components/MapMarkerTest';
// import MapTest from './components/MapTest';
// import GeoLocation from './components/GeoLocation';
import ForecastXML from './components/ForecastXML'

function App() {
  return (
    //  <MapTest />
    // <MapMarkerTest />
    // <CustomOverayTest />
    // <GeoLocation />
    <ForecastXML />
  );
}

export default App;
