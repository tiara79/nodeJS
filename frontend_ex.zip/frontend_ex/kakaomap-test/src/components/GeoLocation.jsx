import { useEffect, useState } from 'react'
import { Map, MapMarker } from 'react-kakao-maps-sdk';

export default function GeoLocation() {
  const [location, setLocation] = useState(null);
  const [level] = useState(3);

  const successHandler = (response) => {
    const { latitude, longitude } = response.coords;
    setLocation({ latitude, longitude });
  };

  const errorHandler = (error) => {
    console.error(error);
  };

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(successHandler, errorHandler);
  }, []);

  return (
    <>
      {location && (
        <>
          <Map
            center={{ lat: location.latitude, lng: location.longitude }}
            style={{ width: '100%', height: '800px' }}
            level={level}
          >
            <MapMarker position={{ lat: location.latitude, lng: location.longitude }} />
          </Map>
          <div>
            현재 위치의 좌표는:
            <p>위도: {location.latitude}</p>
            <p>경도: {location.longitude}</p>
          </div>
        </>
      )}
    </>
  );
}
