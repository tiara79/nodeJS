
import { Map, MapMarker } from 'react-kakao-maps-sdk';

export default function MapMarkerTest() {
  const here={ lat: 37.463266,lng: 126.905945};
  const locations = [
    {title:'남부여성발전센터',latlng: {lat: 37.463266,lng: 126.905945} },
    {title:'산기슭공원',latlng:{lat:37.463716,lng: 126.907402} },
    {title:'한울중학교',latlng:{lat:37.462255,lng: 126.906962} },
    {title:'메가커피',latlng:{ lat:37.463563,lng: 126.904089} }, 
  ]
  return (
    <Map center={here} style={{width:'1900px',height : '800px'}} level={3}>
      {
        locations.map((locations,index)=>(
          <MapMarker key={index} position={locations.latlng} image={{src:'https://cdn-icons-png.flaticon.com/512/1483/1483336.png', size: {height:24,width:35} }} ></MapMarker>
        ))
      }
    </Map>
  )
}
