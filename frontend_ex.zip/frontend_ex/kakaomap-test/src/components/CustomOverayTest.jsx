import { useState } from 'react';
import { Map, CustomOverlayMap } from 'react-kakao-maps-sdk';

export default function CustomOverayTest() {
  const [level, setLevel] = useState(3);

  return (
    <>
      <Map
        center={{ lat: 37.463266, lng: 126.905945 }}
        style={{ width: '100%', height: '800px' }}
        level={level}
      >
        <CustomOverlayMap position={{ lat: 37.463266, lng: 126.905945 }}>
          <div style={styles.card}>남부여성발전센터</div>
        </CustomOverlayMap>
      </Map>
      <div style={{ marginTop: '10px' }}>
        <button onClick={() => setLevel(level + 1)}>축소</button>
        <button onClick={() => setLevel(level - 1)}>확대</button>
      </div>
    </>
  );
}

const styles = {
  card: {
    borderRadius: '8px',
    backgroundColor: 'black',
    color: 'white',
    fontSize: '0.6rem',
    padding: '0.6rem',
  },
};
