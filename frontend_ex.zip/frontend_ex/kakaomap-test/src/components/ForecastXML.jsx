import React, { useState, useEffect } from 'react';


export default function ForecastXML(){
    
    // 덩어리 받을 거임. 3 * 8 * 5 = 40
    const [forecasts, setForeCasts ] = useState([]);
    const [error, setError] = useState(null);

    const city = 'seoul'
    const appId = 'ed36a89e3348f36bf626bb547861b077';

    
    useEffect(()=>{
        const fetchForecast = async()=>{
            try {

                const endPoint = `https://api.openweathermap.org/data/2.5/forecast?appid=${appId}&q=${city}&units=metric&lang=kr&mode=xml`
                const response = await fetch(endPoint);

                if(!response.ok){
                    throw new Error(`날씨 데이터를 가져오지 못했습니다 : ${response.status}`);
                }
                const text = await response.text();
                const parser = new DOMParser();
                const xml = parser.parseFromString(text, 'application/xml');
                
                const timeNodes = xml.getElementsByTagName('time');
                console.log(`timeNodes: `,timeNodes);
                const arrForecast = [];
                // 10개 중에 작은거 
                // for(let i=0; i < Math.min(arrForecast.length; i++);){

                // }
                for(let i=0; i < 10; i++){
                    // 시간 GMT 기준 : + 09
                    const node = timeNodes[i];
                    console.log(`node : `,node);
                    // const str = node.getAttribute('from');
                    // const arrTime = str.split('T')[1];
                    // const strhour = arrTime.slice(0,2); //03
                    const hour = node.getAttribute('from').split('T')[1].slice(0,2);
                    // console.log(`formatted hour:`,strHour);

                    // 온도 
                    const tempNode = node.querySelector('temperature')
                    const temp = tempNode.getAttribute('value');

                    // 날씨 
                    const symbolNode = node.querySelector('symbol');
                    const weather = symbolNode.getAttribute('name');
                    const icon = symbolNode.getAttribute('var');

                    const result = { hour,temp, weather,icon};
                    arrForecast.push(result);   // [ {}, {}, ...]
                }

                setForeCasts(arrForecast);

            } catch (error) {
                setError(error);
            }
       } ;

       
       fetchForecast();
    }, []);
    
    if(error){
        return (<div>오류 발생 :{error.message}</div>);
    }

    // 에러는 없는데 데이터가 없다~ - 네트워크 상태대비 유저에게 노티용
    if(!forecasts){
        return (<div>일기 예보 정보 로딩중...</div> );
    }

    
    return (
        <div>
            {
                forecasts.map((forecast,index)=>{
                    return (
                        <div key={index}>
                            <Img  icon={forecast.icon}></Img>
                            <p>{forecast.hour}시</p>
                            <p>{forecast.weather}</p>
                            <p>🌡️ {forecast.temp} ℃</p>
                        </div>
                    );
                })
            }
        </div>
    );
};


function Img({icon}){
    const imgURL = `https://openweathermap.org/img/wn/${icon}@2x.png`;
    return (
         <img  src={imgURL} alt="날씨 이모티콘" />
    );
}
