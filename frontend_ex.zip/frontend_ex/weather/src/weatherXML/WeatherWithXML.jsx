import React, { useEffect, useState } from "react"


export default function WeatherWithXML(){
  const city ='seoul';
  const appid='264533a6cd1cbdbab96cf5baa69c2d5e';
  const [weather,setWeather] = useState(null);
  const [error,setError] = useState(null);

  useEffect(()=> {
     const fetchWeatherXML = async() =>{

          try{
            const endPoint =
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${appid}&lang=kr&mode=xml`
            const response = await fetch(endPoint)
            if (!response.ok) { throw new Error('데이터를 가져오지 못했습니다.',response.status ) }

            // 참조 : https://api.openweathermap.org/data/2.5/weather?q=seoul&units=metric&appid=264533a6cd1cbdbab96cf5baa69c2d5e&lang=kr&mode=xml
            const text = await response.text();

            // 위의 xml을 js로 사용 하기 위한 parsing
            const parser = new DOMParser();
            const xml = parser.parseFromString(text,'application/xml');

            // <temperature value="17.76" min="17.76" max="19.78" unit="celsius"></temperature>
            const tempNode = xml.querySelector('temperature');
            const temp = tempNode.getAttribute('value');
            
            // <weather number="701" value="박무" icon="50d"></weather>
            const weather = xml.querySelector('weather')?.getAttribute('value');
            const icon = xml.querySelector('weather')?.getAttribute('icon');
            
            setWeather({temp,weather,icon});
          } catch(error) {
                  setError(error);
         }
     }
     fetchWeatherXML();
  },[] )
  if (error) {return <div>오류발생:{error}</div>}
  if (!weather) {return <div>날씨정보 로딩중...</div>}
  return( 
    <div style={style.card}>
      <div style={style.img}>
        <img src={`https://openweathermap.org/img/wn/${weather.icon}@2x.png`} alt=""/>
        <p>{weather.weather}</p>
        <p>🌡️{weather.temp}℃</p>
      </div> 
    </div>
  );
}
const style = {
  card : {
      padding: '0.5rem', 
      borderRadius: '0.5rem',
      backgroundColor: '#e0f7fa',
      textAlign: 'center',
      boxShadow:'0 2px 0.5rem rgba(0.0.0.0.2)',
      width: '5rem',
  },
  img: {width: '5rem'}
};