
import './App.css';
// import Weather from './Weather';
import WeatherWithXML from './WeatherWithXML';

function App() {
  return (
    <div className="App">
       {/* <Weather></Weather> */}
       <WeatherWithXML />
    </div>
  );
}

export default App;



