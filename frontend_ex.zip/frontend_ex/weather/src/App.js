
import './App.css';
import ForcastXML from './forcast/ForcastXML';

function App() {
  return (
    <div className="App">
      <ForcastXML />

    </div>
  );
}

export default App;



