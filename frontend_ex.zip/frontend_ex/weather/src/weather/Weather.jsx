import React, { useEffect, useState } from "react"
      // {  "description": "약간의 구름이 낀 하늘", "main": { "temp": 298.39,} ℃ }
export default function Weather(){
  const city = 'seoul';
  const appid='264533a6cd1cbdbab96cf5baa69c2d5e';
  const [weather,setWeather] = useState(null);
  const [error, setError] = useState(null);

  useEffect(()=> {
     const fetchWeather = async () => {
      try{
          const response = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${appid}&lang=kr`);
          if (!response.ok){
            throw new Error("날씨 정보 가져오기 실패!")
          }
          const data = await response.json();
          setWeather(data);          
      } catch (error) {
          setError(error)
      }
     }
     fetchWeather()
    },[] ); 
    if (error) {return <div>오류발생:{error}</div>}
    if (!weather) {return <div>날씨정보 로딩중...</div>}

  return(
    <div>
      <img src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`} alt=""/>
      <p> {weather.weather[0].description}</p>
      <p> {weather.main.temp }℃</p>
    </div>
  );
}