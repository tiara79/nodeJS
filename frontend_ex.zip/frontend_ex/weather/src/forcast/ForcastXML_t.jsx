import React, { useEffect, useState } from 'react'

export default function ForcastXML() {
  const [forcasts,setForcasts] = useState([]);
  const [error, setError] = useState(null);

  const city ='seoul';
  const appid = '264533a6cd1cbdbab96cf5baa69c2d5e';
  
  // 참조 : https://api.openweathermap.org/data/2.5/forecast?q=seoul&units=metric&appid=264533a6cd1cbdbab96cf5baa69c2d5e&lang=kr&mode=xml
  useEffect(()=>{
    const fetchForcast = async() =>{
      try{
        const endPoint = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${appid}&lang=kr&mode=xml`;
        
        const response = await fetch(endPoint);
        
        if (!response.ok) {
          throw new Error(`데이터를 가져오지 못했습니다. (${response.status})`);
        }

          const text = await response.text();
          const parser = new DOMParser();
          const xml = parser.parseFromString(text,'application/xml'); 

          const timeNodes = xml.getElementsByTagName('time');

          const arrForecast = [];

          // item은 10개로 한정  
          for(let item=0;item< Math.min(timeNodes.length, 10); item++){
              const node = timeNodes[item];

          // 시 <time from="2025-05-29T00:00:00" to="2025-05-29T03:00:00">
           const hour = node.getAttribute('from').split('T')[1].slice(0,2);  //time : '03' 

          // 온도 <temperature unit="celsius" value="22.76" min="22.76" max="24.24"></temperature>
           const tempNode = node.querySelector('temperature');
           const temp = tempNode.getAttribute('value');
              
          // 날씨 <symbol number="803" name="튼구름" var="04d"></symbol>
           const symbolNode = node.querySelector('symbol');
           const weather = symbolNode.getAttribute('name');
           const icon = symbolNode.getAttribute('var');

           const result = {hour,temp,weather,icon}
           arrForecast.push(result);
          }
          setForcasts(arrForecast)
      } catch (error){
            setError(error);
      }
    };
    fetchForecast();
  },[]);
  if(error){
        return (<div>오류 발생 :{error.message}</div>);
  }
  // 에러 출력 없는데 데이터 전송 안될때, 네트워크 상태 알려줌
  if(!forecasts){
        return (<div>일기 예보 정보 로딩중...</div> );
  }
  return (
     <div>
            {
                forecasts.map((forecast,index)=>{
                    return (
                        <div key={index}>
                            <Img  icon={forecast.icon}></Img>
                            <p>{forecast.hour}시</p>
                            <p>{forecast.weather}</p>
                            <p>🌡️ {forecast.temp} ℃</p>
                        </div>
                    );
                })
            }
        </div>
  );
};
function Img({icon}){
    const imgURL = `https://openweathermap.org/img/wn/${icon}@2x.png`;
    return (
         <img style={ {width:'50px', height:'50px'} } src={imgURL} alt="날씨 이모티콘" />
    );
}